from typing import List
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import main
from selenium import webdriver
import chromedriver_autoinstaller
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver import ActionChains
from constants import *
from xpaths import *
from fastapi.middleware.cors import CORSMiddleware

chromedriver_autoinstaller.install()


app = FastAPI()

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Credentials(BaseModel):
    username: str
    password: str


@app.get('/')
def index():
    return {
        'message': 'Acesse a página /docs'
    }


@app.post('/login')
def get_user(credentials: Credentials):
    driver = webdriver.Chrome()
    user = main.get_user(driver, credentials.username, credentials.password)
    driver.quit()
    return user
