PAGE_LOGIN = '/sigaa/verTelaLogin.do'

PAGE_RESTAURANT = '/sipac/restaurante/vendas/saldo_cartao.jsf?voltar=/sigaa/verPortalDiscente'
